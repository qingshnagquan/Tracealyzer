#include <MyExtension.h>

/* The handle to this extension */
TraceExtensionHandle_t xMyExtension = 0;

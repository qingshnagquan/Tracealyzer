Trace Recorder source code for use with Percepio's Tracealyzer.

Read more at https://percepio.com/tracealyzer/ and https://percepio.com/gettingstarted.

Repository at https://github.com/percepio/TraceRecorderSource
